const express = require('express');
const app = express();
const mysql = require('mysql');

const {sequelize, Board} = require('./models'); // 무슨 모델 쓸건지
const { Sequelize } = require('sequelize');

app.use(express.json()); // json 파싱을 위한 사용

sequelize.sync({force:false}) // DB와 연결하기
    .then(() =>{
        console.log('DB 연결 성공');
    })
    .catch((err) => {
        console.err(err);
});



app.post('/post', (req, res)=>{ // 새 글 쓰고싶음
    const newPost = { // 클라이언트 단에서 받아온 걸로 정보 얻어서
        postTitle:req.body.postTitle,
        postContent:req.body.postContent,
        //postLocation:req.body.postLocation
    }

    /* 테스트용 콘솔 출력
    console.log(newPost.postTitle);
    console.log(newPost.postContent)
    console.log(req.body.startLatitude);
    console.log(req.body.startLongitude);
    console.log(req.body.endLatitude);
    console.log(req.body.endLongitude);
    */

    // 그걸로 데이터베이스에 작성할거임
    Board.create(newPost)
    .then((result)=>{ 
    //    console.log("생성 성공"); // 글 잘 써졌으니까 200 신호 보내고 종료
        return res.status(200).send();
    })
    .catch((err)=>{ 
        console.log(err);
    })

});

app.post('/get', (req, res)=>{ // 클라이언트가 정보 요청


    Board.findAll({}) // DB 안에 있는 것 전부 다 찾기
    .then((result) => {
        console.log(JSON.stringify(result));
    })

    Board.findOne({where : {id : 1}}) // 조건 붙여서 찾기 [id = 1]
    .then((result)=>{
        const postInfo = { // 해당 조건에 맞는 것 찾아 객체로 만듬
            postTitle:result.postTitle,
            postContent:result.postContent,
            //postLocation:result.postLocation
        }
        
        console.log(postInfo);
        return res.status(200).send(JSON.stringify(postInfo)); // JSON 파싱해서 보냄
    })
})

app.listen(3000, ()=>{ // 3000 포트에서 리슨 중
    console.log("Listening on port 3000");
})